# Browser demo: temporal evaluation concepts

This folder contains a small, runnable notebook that demonstrates basic data validation and chronological model evaluation concepts related to the `kp-convergence-prediction` project.

## Files
- `kp_convergence_temporal_demo.ipynb` — Jupyter notebook for browser execution.
- `toy_genomes_synthetic.csv` — 16 fully synthetic teaching rows. No real isolates, sequences, measured phenotypes, or study outcomes are included.

## Run it in Google Colab (no local installation)
1. Open [Google Colab](https://colab.research.google.com/).
2. Choose **File → Upload notebook** and select `kp_convergence_temporal_demo.ipynb`.
3. Run the first code cell. If prompted, upload `toy_genomes_synthetic.csv`.
4. Choose **Runtime → Run all** or run each cell from top to bottom.
5. If a common package import fails, run `%pip install pandas numpy matplotlib scikit-learn` in a new cell, then restart the runtime and run all cells.

## What it demonstrates
- checking a dataset's schema and missingness;
- examining observations by collection year;
- training on earlier years and evaluating on later years;
- fitting preprocessing only on training data; and
- computing metrics and inspecting predictions from the run.

## Scientific limitations
The labels and features are synthetic and illustrative. The toy metrics are not evidence about *Klebsiella pneumoniae*, antimicrobial resistance, virulence, or the research hypothesis. The notebook is not a reproduction of the project's 8,318-genome analysis and does not run HyperTraPS-CT, genome annotation, AMR/virulence calling, plasmid analysis, or external bioinformatics tools. Do not use its outputs as manuscript results.

## Before sharing
- Upload both files to a `demo/` folder in the public GitHub repository.
- Open the notebook through Colab and test **Runtime → Run all** in a fresh session.
- Confirm the CSV upload prompt works and all cells finish.
- Keep the synthetic-data disclaimer visible in the notebook and portfolio description.

Colab link after committing to the `main` branch:
`https://colab.research.google.com/github/Sourcify-y/kp-convergence-prediction/blob/main/demo/kp_convergence_temporal_demo.ipynb`
